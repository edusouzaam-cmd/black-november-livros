<?php
// Gerado por wordpress-plugin/build.py
return array(
	'' => 'index.html',
	'politica-de-privacidade' => 'politica-de-privacidade/index.html',
	'termos-de-uso' => 'termos-de-uso/index.html',
);
